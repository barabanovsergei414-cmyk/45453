package com.realweather;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Common (server-side gameplay) settings. */
public final class Config {
    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.BooleanValue NATURAL_STORMS;
    public static final ModConfigSpec.IntValue STORM_INTERVAL_MIN;
    public static final ModConfigSpec.IntValue MAX_STORMS;
    public static final ModConfigSpec.DoubleValue TORNADO_CHANCE;
    public static final ModConfigSpec.DoubleValue TIME_SCALE;
    public static final ModConfigSpec.DoubleValue STORM_SIZE;
    public static final ModConfigSpec.BooleanValue TORNADO_BLOCK_DAMAGE;
    public static final ModConfigSpec.BooleanValue TORNADO_ENTITY_DAMAGE;
    public static final ModConfigSpec.IntValue MAX_DEBRIS;
    public static final ModConfigSpec.BooleanValue REAL_LIGHTNING;
    public static final ModConfigSpec.IntValue CLOUD_BASE_Y;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();
        b.comment("RealWeather: storms, lightning and tornadoes").push("storms");
        NATURAL_STORMS = b.comment("Storms form by themselves near players").define("naturalStorms", true);
        STORM_INTERVAL_MIN = b.comment("Average minutes between natural storms").defineInRange("stormIntervalMinutes", 25, 2, 240);
        MAX_STORMS = b.comment("Maximum number of storms alive at once").defineInRange("maxStorms", 2, 1, 6);
        TORNADO_CHANCE = b.comment("Chance that a natural storm is a tornadic supercell (0..1)").defineInRange("tornadoChance", 0.4, 0.0, 1.0);
        TIME_SCALE = b.comment("Storm life cycle speed (1 = about 15 minutes to a full anvil + tornado)").defineInRange("timeScale", 1.0, 0.2, 20.0);
        STORM_SIZE = b.comment("Size multiplier of storm clouds").defineInRange("stormSize", 1.0, 0.5, 3.0);
        CLOUD_BASE_Y = b.comment("Height of the cloud base (blocks)").defineInRange("cloudBaseY", 230, 120, 280);
        b.pop();
        b.push("tornado");
        TORNADO_BLOCK_DAMAGE = b.comment("Tornado destroys blocks").define("blockDamage", true);
        TORNADO_ENTITY_DAMAGE = b.comment("Tornado throws and hurts entities").define("entityDamage", true);
        MAX_DEBRIS = b.comment("Maximum flying block debris per tornado").defineInRange("maxDebris", 40, 0, 200);
        REAL_LIGHTNING = b.comment("Lightning near players is real (damage, fire). Otherwise visual only").define("realLightning", true);
        b.pop();
        SPEC = b.build();
    }

    private Config() {}
}
