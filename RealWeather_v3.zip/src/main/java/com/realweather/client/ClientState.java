package com.realweather.client;

import com.realweather.storm.StormData;

import java.util.ArrayList;
import java.util.List;

/** Everything the client knows about the weather. */
public final class ClientState {
    public static final List<StormData> storms = new ArrayList<>();
    public static long worldSeed = 0L;
    public static float windAngle = 0f;
    public static boolean synced = false;
    public static long tick = 0L;

    // Smoothed values at the player's position (0..1)
    public static float skyStorm = 0f;   // darkness of the sky above (anvil / tower)
    public static float rain = 0f;       // rain intensity at the player
    public static float overcast = 0f;   // overcast sky from the day's weather mood
    public static float cirrus = 0f;     // amount of high thin cloud
    public static float skyFlash = 0f;   // sky brightening by lightning
    public static float screenFlash = 0f;// white screen flash by close lightning
    public static float wind = 0f;       // wind loudness
    public static float tornadoRumble = 0f;

    public static final List<LightningRenderer.Flash> flashes = new ArrayList<>();
    public static final List<LightningRenderer.Thunder> thunders = new ArrayList<>();

    private ClientState() {}

    public static void reset() {
        storms.clear();
        flashes.clear();
        thunders.clear();
        synced = false;
        skyStorm = 0f;
        rain = 0f;
        overcast = 0f;
        cirrus = 0f;
        skyFlash = 0f;
        screenFlash = 0f;
        wind = 0f;
        tornadoRumble = 0f;
        StormClouds.clearCache();
        AmbientClouds.clearCache();
    }
}
