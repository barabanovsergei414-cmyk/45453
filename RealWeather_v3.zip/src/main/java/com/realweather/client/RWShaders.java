package com.realweather.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.realweather.RealWeather;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;

import java.util.function.Consumer;

/** Custom GLSL programs. If one fails to compile the mod falls back to vanilla shaders instead of crashing. */
public final class RWShaders {
    public static ShaderInstance sky;
    public static ShaderInstance puff;
    public static ShaderInstance add;

    private RWShaders() {}

    public static void onRegisterShaders(RegisterShadersEvent event) {
        reg(event, "rw_sky", DefaultVertexFormat.POSITION, s -> sky = s);
        reg(event, "rw_puff", DefaultVertexFormat.POSITION_TEX_COLOR, s -> puff = s);
        reg(event, "rw_add", DefaultVertexFormat.POSITION_TEX_COLOR, s -> add = s);
    }

    private static void reg(RegisterShadersEvent event, String name, VertexFormat format, Consumer<ShaderInstance> sink) {
        try {
            ShaderInstance inst = new ShaderInstance(event.getResourceProvider(),
                    ResourceLocation.fromNamespaceAndPath(RealWeather.MODID, name), format);
            event.registerShader(inst, sink);
        } catch (Exception ex) {
            RealWeather.LOGGER.error("RealWeather: shader {} failed to load, using fallback", name, ex);
        }
    }

    /** Select the textured+coloured program. Additive = glow (lightning), otherwise normal alpha blending. */
    public static void useTexColor(boolean additive) {
        ShaderInstance s = additive ? add : puff;
        if (s != null) {
            RenderSystem.setShader(() -> s);
        } else {
            RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
            RenderSystem.enableBlend();
            if (additive) {
                RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
            } else {
                RenderSystem.defaultBlendFunc();
            }
        }
    }
}
