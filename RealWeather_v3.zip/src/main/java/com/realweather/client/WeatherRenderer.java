package com.realweather.client;

import com.realweather.ClientConfig;
import com.realweather.storm.StormData;

/** Draws everything that lives in the sky after the terrain: shafts, lightning, funnels, clouds, shadows. */
public final class WeatherRenderer {
    private WeatherRenderer() {}

    /** Called once per frame in the translucent stage. */
    public static void render() {
        PuffBuffer.clear();
        ShadowCasters.clear();

        // gather: storms first, then everyday clouds
        for (StormData s : ClientState.storms) {
            StormClouds.emit(s);
        }
        if (ClientConfig.AMBIENT_CLOUDS.get()) {
            AmbientClouds.emit();
        }
        TornadoRenderer.emitDust();
        RainShaftRenderer.emitMist();

        Gfx.beginView(Frame.modelView);
        try {
            ShadowRenderer.draw();
            RainShaftRenderer.draw();
            LightningRenderer.draw();
            TornadoRenderer.draw();
            PuffBuffer.draw();
        } finally {
            Gfx.endView();
            Gfx.resetState();
        }
    }
}
