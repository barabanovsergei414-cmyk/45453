package com.realweather.client;

/** Lights a puff (sun, haze, lightning) and hands it to the frame buffer. */
public final class Puffs {
    private static final float[] col = new float[3];

    private Puffs() {}

    public static void emit(double wx, double wy, double wz, float size, float flat,
                            float nx, float ny, float nz, float hf, float dark, float alpha, float rot, int variant) {
        Frame.shade(nx, ny, nz, hf, dark, col);
        finish(wx, wy, wz, size, flat, col[0], col[1], col[2], alpha, rot, variant);
    }

    /** Colour given directly (dust, mist). Applies haze, far fade and lightning glow. */
    public static void finish(double wx, double wy, double wz, float size, float flat,
                              float r, float g, float b, float alpha, float rot, int variant) {
        float dx = (float) (wx - Frame.cx), dy = (float) (wy - Frame.cy), dz = (float) (wz - Frame.cz);
        float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        float t = dist / Frame.drawDist;
        float haze = SkyModel.smoothstep(0.30f, 1.0f, t) * 0.70f;
        r = r + (Frame.horizon[0] - r) * haze;
        g = g + (Frame.horizon[1] - g) * haze;
        b = b + (Frame.horizon[2] - b) * haze;
        alpha *= 1f - SkyModel.smoothstep(0.82f, 1.0f, t);
        float fb = LightningRenderer.boost(wx, wy, wz);
        if (fb > 0f) {
            r += fb * 0.55f;
            g += fb * 0.65f;
            b += fb * 1.00f;
        }
        PuffBuffer.add(wx, wy, wz, size, flat, r, g, b, alpha, rot, variant);
    }
}
