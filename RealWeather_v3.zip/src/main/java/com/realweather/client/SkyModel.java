package com.realweather.client;

import net.minecraft.client.multiplayer.ClientLevel;

/** CPU copy of the colour model used by the sky shader (for fog, haze and cloud tint). */
public final class SkyModel {
    private SkyModel() {}

    public static float smoothstep(float a, float b, float x) {
        float t = (x - a) / (b - a);
        t = t < 0f ? 0f : (t > 1f ? 1f : t);
        return t * t * (3f - 2f * t);
    }

    public static float mix(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** Sun elevation (sin) from the level time. Sun path matches vanilla: east -> zenith -> west. */
    public static float sunY(ClientLevel level, float partial) {
        float a = level.getTimeOfDay(partial) * (float) (Math.PI * 2.0);
        return (float) Math.cos(a);
    }

    public static void sunDir(ClientLevel level, float partial, float[] out) {
        float a = level.getTimeOfDay(partial) * (float) (Math.PI * 2.0);
        out[0] = (float) -Math.sin(a);
        out[1] = (float) Math.cos(a);
        out[2] = 0f;
    }

    /** Horizon colour (what the terrain fog should blend to). */
    public static void horizon(float sunY, float storm, float overcast, float[] out) {
        float day = smoothstep(-0.18f, 0.12f, sunY);
        float dusk = (float) Math.exp(-Math.pow(sunY / 0.16f, 2.0));
        float r = mix(0.035f, 0.66f, day);
        float g = mix(0.050f, 0.79f, day);
        float b = mix(0.100f, 0.95f, day);
        r = mix(r, 1.0f, dusk * 0.5f);
        g = mix(g, 0.50f, dusk * 0.5f);
        b = mix(b, 0.26f, dusk * 0.5f);
        float k = 0.16f + 0.84f * day;
        float sr = 0.42f * k, sg = 0.47f * k, sb = 0.38f * k;
        r = mix(r, sr, storm * 0.90f);
        g = mix(g, sg, storm * 0.90f);
        b = mix(b, sb, storm * 0.90f);
        float gr = mix(0.05f, 0.72f, day), gg = mix(0.055f, 0.74f, day), gb = mix(0.07f, 0.76f, day);
        r = mix(r, gr, overcast * 0.78f);
        g = mix(g, gg, overcast * 0.78f);
        b = mix(b, gb, overcast * 0.78f);
        out[0] = r / (1f + r * 0.18f);
        out[1] = g / (1f + g * 0.18f);
        out[2] = b / (1f + b * 0.18f);
    }
}
