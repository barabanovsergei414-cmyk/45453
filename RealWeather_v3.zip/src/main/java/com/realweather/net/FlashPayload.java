package com.realweather.net;

import com.realweather.RealWeather;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Server -> client: one lightning event. */
public record FlashPayload(float x, float groundY, float z, float cloudY, int kind, int seed, float dirX, float dirZ, float length)
        implements CustomPacketPayload {

    public static final int CG = 0;        // cloud to ground, drawn by the mod
    public static final int IC = 1;        // inside the cloud (branching flash)
    public static final int CC = 2;        // anvil crawler, long horizontal discharge
    public static final int CG_REAL = 3;   // vanilla lightning entity exists (only glow + no mod bolt)
    public static final int SHEET = 4;     // sheet lightning, whole cloud lights up

    public static final CustomPacketPayload.Type<FlashPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(RealWeather.MODID, "flash"));

    public static final StreamCodec<FriendlyByteBuf, FlashPayload> CODEC =
            StreamCodec.of(FlashPayload::write, FlashPayload::read);

    private static void write(FriendlyByteBuf b, FlashPayload p) {
        b.writeFloat(p.x);
        b.writeFloat(p.groundY);
        b.writeFloat(p.z);
        b.writeFloat(p.cloudY);
        b.writeByte(p.kind);
        b.writeInt(p.seed);
        b.writeFloat(p.dirX);
        b.writeFloat(p.dirZ);
        b.writeFloat(p.length);
    }

    private static FlashPayload read(FriendlyByteBuf b) {
        float x = b.readFloat();
        float gy = b.readFloat();
        float z = b.readFloat();
        float cy = b.readFloat();
        int kind = b.readByte();
        int seed = b.readInt();
        float dx = b.readFloat();
        float dz = b.readFloat();
        float len = b.readFloat();
        return new FlashPayload(x, gy, z, cy, kind, seed, dx, dz, len);
    }

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
