package com.realweather.storm;

import com.realweather.Config;
import com.realweather.net.FlashPayload;
import com.realweather.net.StormSyncPayload;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Server side storm simulation for the overworld. */
public final class StormManager {
    public static final StormManager INSTANCE = new StormManager();

    public final List<StormData> storms = new ArrayList<>();
    /** -2 = random (auto), -1 = no tornado, 0..5 = EF0..EF5 */
    public int forcedCategory = -2;
    private int nextId = 1;
    private final RandomSource rnd = RandomSource.create();
    private final double[] tmp = new double[2];

    private StormManager() {}

    public void reset() {
        storms.clear();
        forcedCategory = -2;
        nextId = 1;
    }

    // ------------------------------------------------------------------ tick
    public void tick(ServerLevel level) {
        long time = level.getGameTime();
        List<ServerPlayer> players = level.players();

        Iterator<StormData> it = storms.iterator();
        while (it.hasNext()) {
            StormData s = it.next();
            s.tick();
            boolean far = true;
            for (ServerPlayer p : players) {
                double dx = p.getX() - s.x, dz = p.getZ() - s.z;
                if (dx * dx + dz * dz < 9000.0 * 9000.0) {
                    far = false;
                    break;
                }
            }
            if (s.age >= s.life || far || players.isEmpty()) {
                it.remove();
            }
        }

        if (Config.NATURAL_STORMS.get() && !players.isEmpty() && time % 200 == 0 && storms.size() < Config.MAX_STORMS.get()) {
            double perCheck = 200.0 / (Config.STORM_INTERVAL_MIN.get() * 1200.0);
            if (rnd.nextDouble() < perCheck) {
                spawnNatural(level, players.get(rnd.nextInt(players.size())));
            }
        }

        for (StormData s : storms) {
            tickLightning(level, s, players);
            if (s.hasTornado() && s.touching(s.age) && time % 2 == 0) {
                boolean near = false;
                s.tornadoPos(s.age, tmp);
                for (ServerPlayer p : players) {
                    double dx = p.getX() - tmp[0], dz = p.getZ() - tmp[1];
                    if (dx * dx + dz * dz < 420.0 * 420.0) {
                        near = true;
                        break;
                    }
                }
                if (near) {
                    TornadoEffects.tick(level, s, rnd);
                }
            }
        }

        if (time % 10 == 0) {
            syncAll(level);
        }
    }

    // ------------------------------------------------------------------ spawning
    public StormData spawnNatural(ServerLevel level, ServerPlayer target) {
        float wind = StormData.windAngle(level.getSeed());
        float ang = wind + (rnd.nextFloat() - 0.5f) * 0.5f;
        float dx = (float) Math.cos(ang), dz = (float) Math.sin(ang);
        double dist = 3200 + rnd.nextInt(1800);
        double lateral = (rnd.nextDouble() - 0.5) * 1600.0;
        double sx = target.getX() - dx * dist - dz * lateral;
        double sz = target.getZ() - dz * dist + dx * lateral;
        int kind = randomKind();
        boolean tornado = kind == StormData.KIND_SUPERCELL && rnd.nextDouble() < Config.TORNADO_CHANCE.get() / 0.6;
        return create(level, sx, sz, ang, kind, tornado ? pickCategory() : -1, (float) Config.TIME_SCALE.get().doubleValue());
    }

    public int randomKind() {
        float r = rnd.nextFloat();
        if (r < 0.40f) return StormData.KIND_CELL;
        if (r < 0.70f) return StormData.KIND_SUPERCELL;
        if (r < 0.88f) return StormData.KIND_SQUALL;
        return StormData.KIND_DRY;
    }

    private int pickCategory() {
        if (forcedCategory >= 0) return forcedCategory;
        if (forcedCategory == -1) return -1;
        float r = rnd.nextFloat();
        if (r < 0.28f) return 0;
        if (r < 0.58f) return 1;
        if (r < 0.80f) return 2;
        if (r < 0.92f) return 3;
        if (r < 0.98f) return 4;
        return 5;
    }

    /** Spawn a storm for a command: it comes towards the given player. */
    public StormData spawnNear(ServerLevel level, ServerPlayer p, boolean fast, int category, int kind) {
        float wind = StormData.windAngle(level.getSeed());
        float dx = (float) Math.cos(wind), dz = (float) Math.sin(wind);
        double dist = fast ? 520 : 1300;
        double lateral = (rnd.nextDouble() - 0.5) * 120.0;
        double sx = p.getX() - dx * dist - dz * lateral;
        double sz = p.getZ() - dz * dist + dx * lateral;
        float k = fast ? 8f : (float) Config.TIME_SCALE.get().doubleValue();
        return create(level, sx, sz, wind, kind, category, k);
    }

    public StormData create(ServerLevel level, double x, double z, float dirAngle, int kind, int category, float timeScale) {
        StormData s = new StormData();
        s.id = nextId++;
        s.seed = rnd.nextLong();
        s.kind = kind;
        s.x = x;
        s.z = z;
        float speed = 0.11f + rnd.nextFloat() * 0.07f;
        s.vx = (float) Math.cos(dirAngle) * speed;
        s.vz = (float) Math.sin(dirAngle) * speed;
        float base = kind == StormData.KIND_SUPERCELL ? 1.15f : (kind == StormData.KIND_SQUALL ? 1.0f : 0.9f);
        s.size = (float) (base * (0.9 + rnd.nextFloat() * 0.3) * Config.STORM_SIZE.get());
        float k = Math.max(0.05f, timeScale);
        s.towerEnd = (int) (7000 / k);
        s.anvilStart = (int) (4200 / k);
        s.anvilEnd = (int) (14500 / k);
        s.matureStart = (int) (9000 / k);
        s.life = s.anvilEnd + (int) (12000 / k);
        if (category >= 0) {
            setupTornado(s, category, k, false);
        }
        storms.add(s);
        return s;
    }

    /** Gives a storm a tornado. If the anvil is already there, the funnel starts soon. */
    public void setupTornado(StormData s, int category, float timeScale, boolean startSoon) {
        float k = Math.max(0.05f, timeScale);
        if (s.kind != StormData.KIND_SUPERCELL) {
            s.kind = StormData.KIND_SUPERCELL;
        }
        s.category = category;
        s.tornGrow = (int) (2400 / k);
        float hk = k > 1f ? 1f + (k - 1f) * 0.4f : k;
        s.tornHold = (int) ((7000 + rnd.nextInt(5000)) / hk);
        s.tornRope = (int) (2400 / k);
        int natural = s.anvilEnd + (int) (600 / k);
        if (startSoon) {
            s.tornStart = Math.max(s.age + 60, Math.min(natural, s.age + 200));
        } else {
            s.tornStart = natural;
        }
        int end = s.tornStart + s.tornGrow + s.tornHold + s.tornRope + Math.max(2400, (int) (6000 / k));
        s.life = Math.max(s.life, end);
    }

    public StormData nearest(double x, double z) {
        StormData best = null;
        double bd = Double.MAX_VALUE;
        for (StormData s : storms) {
            double dx = s.x - x, dz = s.z - z;
            double d = dx * dx + dz * dz;
            if (d < bd) {
                bd = d;
                best = s;
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ lightning
    private void tickLightning(ServerLevel level, StormData s, List<ServerPlayer> players) {
        float a = s.age;
        float intensity = StormData.smooth((a - s.towerEnd * 0.55f) / (s.towerEnd * 0.45f)) * (1f - s.dissipate(a));
        if (intensity <= 0.02f) return;
        float rate = s.lightningRate() * intensity;
        if (rnd.nextFloat() >= rate) return;

        float baseY = Config.CLOUD_BASE_Y.get() + s.baseOffsetY();
        float topY = baseY + s.towerHeight();
        float r = rnd.nextFloat();
        int kind;
        double fx, fz;
        float len = 0f, ddx = 0f, ddz = 0f;
        double core = s.towerRadius();
        if (r < 0.45f) {
            kind = FlashPayload.IC;
            double ang = rnd.nextDouble() * Math.PI * 2;
            double rad = Math.sqrt(rnd.nextDouble()) * core * 1.1;
            fx = s.x + Math.cos(ang) * rad;
            fz = s.z + Math.sin(ang) * rad;
        } else if (r < 0.60f) {
            kind = FlashPayload.SHEET;
            double ang = rnd.nextDouble() * Math.PI * 2;
            double rad = Math.sqrt(rnd.nextDouble()) * core * 0.9;
            fx = s.x + Math.cos(ang) * rad;
            fz = s.z + Math.sin(ang) * rad;
        } else if (r < 0.72f && s.anvil(a) > 0.35f) {
            kind = FlashPayload.CC;
            double along = 0.15 + rnd.nextDouble() * 0.5;
            fx = s.x + s.dirX() * s.anvilRadius() * along * s.anvil(a);
            fz = s.z + s.dirZ() * s.anvilRadius() * along * s.anvil(a);
            double ang = rnd.nextDouble() * Math.PI * 2;
            ddx = (float) Math.cos(ang);
            ddz = (float) Math.sin(ang);
            len = (float) (200 + rnd.nextDouble() * 500) * s.size;
        } else {
            kind = FlashPayload.CG;
            double ang = rnd.nextDouble() * Math.PI * 2;
            double rad = Math.sqrt(rnd.nextDouble()) * s.rainRadius() * 0.8;
            double[] rc = new double[2];
            s.rainCenter(rc);
            fx = rc[0] + Math.cos(ang) * rad;
            fz = rc[1] + Math.sin(ang) * rad;
        }

        float groundY = level.getSeaLevel();
        boolean loaded = level.hasChunkAt(BlockPos.containing(fx, level.getSeaLevel(), fz));
        if (loaded) {
            groundY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) fx, (int) fz);
        }
        float cloudY = (kind == FlashPayload.CC) ? topY - 70f * s.size
                : (kind == FlashPayload.CG ? baseY - 8f : baseY + rnd.nextFloat() * (topY - baseY) * 0.8f);

        boolean realStrike = false;
        if (kind == FlashPayload.CG && loaded) {
            for (ServerPlayer p : players) {
                double dx = p.getX() - fx, dz = p.getZ() - fz;
                if (dx * dx + dz * dz < 220.0 * 220.0) {
                    realStrike = true;
                    break;
                }
            }
        }
        if (realStrike) {
            kind = FlashPayload.CG_REAL;
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
            if (bolt != null) {
                bolt.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(fx, groundY, fz)));
                bolt.setVisualOnly(!Config.REAL_LIGHTNING.get());
                level.addFreshEntity(bolt);
            }
        }

        FlashPayload payload = new FlashPayload((float) fx, groundY, (float) fz, cloudY, kind, rnd.nextInt(), ddx, ddz, len);
        for (ServerPlayer p : players) {
            double dx = p.getX() - fx, dz = p.getZ() - fz;
            if (dx * dx + dz * dz < 7000.0 * 7000.0) {
                PacketDistributor.sendToPlayer(p, payload);
            }
        }
    }

    // ------------------------------------------------------------------ sync
    public void syncAll(ServerLevel level) {
        StormSyncPayload payload = new StormSyncPayload(level.getSeed(), new ArrayList<>(storms));
        for (ServerPlayer p : level.players()) {
            PacketDistributor.sendToPlayer(p, payload);
        }
    }

    public void syncTo(ServerLevel level, ServerPlayer p) {
        PacketDistributor.sendToPlayer(p, new StormSyncPayload(level.getSeed(), new ArrayList<>(storms)));
    }
}
