package com.realweather.storm;

import com.realweather.Config;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** What a touching tornado does to entities and blocks. Called every 2 ticks while players are close. */
public final class TornadoEffects {
    private static final float[] PUSH = {0.020f, 0.040f, 0.075f, 0.120f, 0.170f, 0.230f};
    private static final float[] BLOCK_RESIST = {0.25f, 0.4f, 3.0f, 3.0f, 6.0f, 50.0f};

    private TornadoEffects() {}

    public static void tick(ServerLevel level, StormData s, RandomSource rnd) {
        double[] p = new double[2];
        s.tornadoPos(s.age, p);
        int cat = Math.max(0, Math.min(5, s.category));
        float radius = s.groundRadius(s.age);
        if (radius < 2f) return;

        int cx = (int) Math.floor(p[0]);
        int cz = (int) Math.floor(p[1]);
        if (!level.hasChunkAt(new BlockPos(cx, level.getSeaLevel(), cz))) return;
        int gy = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx, cz);

        if (Config.TORNADO_ENTITY_DAMAGE.get()) {
            pushEntities(level, p, gy, radius, cat, s, rnd);
        }
        if (Config.TORNADO_BLOCK_DAMAGE.get() && level.getGameTime() % 4 == 0) {
            damageBlocks(level, p, radius, cat, rnd);
        }
    }

    private static void pushEntities(ServerLevel level, double[] p, int gy, float radius, int cat, StormData s, RandomSource rnd) {
        double suction = radius * 4.0 + 12.0;
        AABB box = new AABB(p[0] - suction, gy - 6, p[1] - suction, p[0] + suction, gy + 150, p[1] + suction);
        List<Entity> list = level.getEntitiesOfClass(Entity.class, box, e -> {
            if (!e.isAlive()) return false;
            if (e instanceof Player pl && (pl.isCreative() || pl.isSpectator())) return false;
            return true;
        });
        float push = PUSH[cat];
        for (Entity e : list) {
            double dx = e.getX() - p[0];
            double dz = e.getZ() - p[1];
            double d = Math.sqrt(dx * dx + dz * dz) + 0.001;
            if (d > suction) continue;
            double f = 1.0 - d / suction;
            f = f * f;
            double inner = d < radius * 2.0 ? 1.0 : 0.35;
            double tx = -dz / d, tz = dx / d;
            double ix = -dx / d, iz = -dz / d;
            Vec3 m = e.getDeltaMovement();
            double mx = m.x * 0.94 + (tx * 0.55 + ix * 0.45) * push * 3.0 * f;
            double mz = m.z * 0.94 + (tz * 0.55 + iz * 0.45) * push * 3.0 * f;
            double lift = cat >= 2 ? push * 2.6 * f * inner : push * 0.5 * f;
            double my = m.y + lift;
            double hs = Math.sqrt(mx * mx + mz * mz);
            double hmax = 0.9 + cat * 0.12;
            if (hs > hmax) {
                mx *= hmax / hs;
                mz *= hmax / hs;
            }
            if (my > 0.75) my = 0.75;
            e.setDeltaMovement(mx, my, mz);
            e.hurtMarked = true;
            if (cat >= 1 && d < radius * 1.3 && level.getGameTime() % 10 == 0 && !(e instanceof FallingBlockEntity)) {
                float dmg = 1.5f + cat * 2.5f;
                e.hurt(level.damageSources().generic(), dmg);
            }
        }
    }

    private static void damageBlocks(ServerLevel level, double[] p, float radius, int cat, RandomSource rnd) {
        int tries = 5 + cat * 5;
        float resist = BLOCK_RESIST[cat];
        int debris = -1;
        for (int i = 0; i < tries; i++) {
            double ang = rnd.nextDouble() * Math.PI * 2;
            double rad = Math.sqrt(rnd.nextDouble()) * radius * 1.4;
            int bx = (int) Math.floor(p[0] + Math.cos(ang) * rad);
            int bz = (int) Math.floor(p[1] + Math.sin(ang) * rad);
            BlockPos probe = new BlockPos(bx, level.getSeaLevel(), bz);
            if (!level.hasChunkAt(probe)) continue;
            int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, bx, bz);
            int depth = rnd.nextInt(2 + cat);
            BlockPos pos = new BlockPos(bx, top - 1 - depth, bz);
            BlockState st = level.getBlockState(pos);
            if (st.isAir() || !st.getFluidState().isEmpty()) continue;
            float hardness = st.getDestroySpeed(level, pos);
            if (hardness < 0f) continue;
            if (level.getBlockEntity(pos) != null) continue;
            boolean ground = st.is(BlockTags.DIRT) || st.is(BlockTags.SAND) || st.is(BlockTags.BASE_STONE_OVERWORLD)
                    || st.is(BlockTags.TERRACOTTA) || st.is(BlockTags.SNOW);
            if (ground && (cat < 5 || depth > 0)) continue;
            if (st.getBlock().getExplosionResistance() > resist) continue;

            if (cat >= 2 && Config.MAX_DEBRIS.get() > 0 && rnd.nextFloat() < 0.4f) {
                if (debris < 0) {
                    AABB box = new AABB(p[0] - 220, level.getMinBuildHeight(), p[1] - 220, p[0] + 220, level.getMaxBuildHeight(), p[1] + 220);
                    debris = level.getEntitiesOfClass(FallingBlockEntity.class, box).size();
                }
                if (debris < Config.MAX_DEBRIS.get()) {
                    FallingBlockEntity fb = FallingBlockEntity.fall(level, pos, st);
                    fb.dropItem = false;
                    double tx = -Math.sin(ang), tz = Math.cos(ang);
                    fb.setDeltaMovement(tx * 0.5, 0.45 + rnd.nextDouble() * 0.5, tz * 0.5);
                    fb.hurtMarked = true;
                    debris++;
                    continue;
                }
            }
            level.destroyBlock(pos, false);
        }
    }
}
